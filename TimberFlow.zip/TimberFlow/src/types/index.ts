export interface DataRecord {
  id: string;
  reason: string;
  source: string;
  scale: string;
  dateIn: string;
  bol: string; // Bill of Lading
  stumpageOwner: string;
  contractor: string;
  state: string;
  county: string;
  condition: string;
  tier: string;
  truckNumber: string;
  logCount: number;
  avgLogLength: number;
  avgSED: number; // Small End Diameter
  yardDeck: string;
  comments: string;
  grossWeightIn: number;
  tareWeightOut: number;
  deductWeight: number;
  adjustedNetWeight: number;
  deductDetails: DeductDetail[];
  dateCreated: string;
  lastModified: string;
}

export interface DeductDetail {
  id: string;
  code: string;
  ton: number;
}

export interface FilterOptions {
  search: string;
  source: string;
  condition: string;
  tier: string;
  state: string;
  contractor: string;
}

export interface SortConfig {
  key: keyof DataRecord;
  direction: 'asc' | 'desc';
}

export interface User {
  id: string;
  username: string;
  email: string;
  location: string;
  role: 'admin' | 'user' | 'manager';
  lastLogin: string;
}

export interface LoginCredentials {
  username: string;
  password: string;
  location: string;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  loading: boolean;
}