import { DataRecord, FilterOptions, SortConfig } from '../types';

export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

export const getCurrentDateTime = (): string => {
  return new Date().toISOString().split('T')[0];
};

export const filterData = (data: DataRecord[], filters: FilterOptions): DataRecord[] => {
  return data.filter(record => {
    const matchesSearch = !filters.search || 
      Object.values(record).some(value => {
        if (typeof value === 'string') {
          return value.toLowerCase().includes(filters.search.toLowerCase());
        }
        if (typeof value === 'number') {
          return value.toString().includes(filters.search);
        }
        if (Array.isArray(value)) {
          return value.some(item => 
            typeof item === 'object' && item !== null &&
            Object.values(item).some(subValue => 
              typeof subValue === 'string' && 
              subValue.toLowerCase().includes(filters.search.toLowerCase())
            )
          );
        }
        return false;
      });
    
    const matchesSource = !filters.source || record.source === filters.source;
    const matchesCondition = !filters.condition || record.condition === filters.condition;
    const matchesTier = !filters.tier || record.tier === filters.tier;
    const matchesState = !filters.state || record.state === filters.state;
    const matchesContractor = !filters.contractor || record.contractor === filters.contractor;
    
    return matchesSearch && matchesSource && matchesCondition && matchesTier && matchesState && matchesContractor;
  });
};

export const sortData = (data: DataRecord[], sortConfig: SortConfig): DataRecord[] => {
  return [...data].sort((a, b) => {
    const aValue = a[sortConfig.key];
    const bValue = b[sortConfig.key];
    
    if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
    if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
    return 0;
  });
};

export const exportToCSV = (data: DataRecord[], filename: string = 'data-export.csv') => {
  if (data.length === 0) return;

  // Create headers
  const headers = [
    'Date In', 'BOL', 'Reason', 'Source', 'Scale', 'Stumpage Owner', 'Contractor',
    'State', 'County', 'Condition', 'Tier', 'Truck Number', 'Log Count',
    'Avg Log Length', 'Avg SED', 'Yard/Deck', 'Gross Weight IN', 'Tare Weight OUT',
    'Deduct Weight', 'Adjusted Net Weight', 'Deduct Details', 'Comments'
  ];

  // Create CSV content
  const csvContent = [
    headers.join(','),
    ...data.map(record => [
      record.dateIn,
      `"${record.bol}"`,
      `"${record.reason}"`,
      `"${record.source}"`,
      `"${record.scale}"`,
      `"${record.stumpageOwner}"`,
      `"${record.contractor}"`,
      `"${record.state}"`,
      `"${record.county}"`,
      `"${record.condition}"`,
      `"${record.tier}"`,
      `"${record.truckNumber}"`,
      record.logCount,
      record.avgLogLength,
      record.avgSED,
      `"${record.yardDeck}"`,
      record.grossWeightIn,
      record.tareWeightOut,
      record.deductWeight,
      record.adjustedNetWeight,
      `"${record.deductDetails.map(d => `${d.code}:${d.ton}t`).join('; ')}"`,
      `"${record.comments}"`
    ].join(','))
  ].join('\n');
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};