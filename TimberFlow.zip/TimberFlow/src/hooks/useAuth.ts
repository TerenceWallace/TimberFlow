import { useState, useEffect } from 'react';
import { User, LoginCredentials, AuthState } from '../types';
import { useLocalStorage } from './useLocalStorage';

// Mock user database - in production, this would be handled by your backend
const mockUsers: Array<User & { password: string }> = [
  {
    id: '1',
    username: 'admin',
    password: 'admin123',
    email: 'admin@dataflow.com',
    location: 'New York',
    role: 'admin',
    lastLogin: new Date().toISOString()
  },
  {
    id: '2',
    username: 'manager',
    password: 'manager123',
    email: 'manager@dataflow.com',
    location: 'Los Angeles',
    role: 'manager',
    lastLogin: new Date().toISOString()
  },
  {
    id: '3',
    username: 'user',
    password: 'user123',
    email: 'user@dataflow.com',
    location: 'Chicago',
    role: 'user',
    lastLogin: new Date().toISOString()
  }
];

export const useAuth = () => {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    user: null,
    loading: true
  });
  
  const [storedUser, setStoredUser] = useLocalStorage<User | null>('dataflow-user', null);

  useEffect(() => {
    // Check if user is already logged in
    if (storedUser) {
      setAuthState({
        isAuthenticated: true,
        user: storedUser,
        loading: false
      });
    } else {
      setAuthState(prev => ({ ...prev, loading: false }));
    }
  }, [storedUser]);

  const login = async (credentials: LoginCredentials): Promise<{ success: boolean; error?: string }> => {
    setAuthState(prev => ({ ...prev, loading: true }));

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    const user = mockUsers.find(
      u => u.username === credentials.username && 
           u.password === credentials.password &&
           u.location === credentials.location
    );

    if (user) {
      const { password, ...userWithoutPassword } = user;
      const updatedUser = {
        ...userWithoutPassword,
        lastLogin: new Date().toISOString()
      };

      setStoredUser(updatedUser);
      setAuthState({
        isAuthenticated: true,
        user: updatedUser,
        loading: false
      });

      return { success: true };
    } else {
      setAuthState(prev => ({ ...prev, loading: false }));
      return { 
        success: false, 
        error: 'Invalid username, password, or location. Please check your credentials.' 
      };
    }
  };

  const logout = () => {
    setStoredUser(null);
    setAuthState({
      isAuthenticated: false,
      user: null,
      loading: false
    });
  };

  return {
    ...authState,
    login,
    logout
  };
};