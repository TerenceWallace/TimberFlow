import React, { useState, useEffect } from 'react';
import { X, Save, Truck, Plus, Trash2 } from 'lucide-react';
import { DataRecord, DeductDetail } from '../types';
import { generateId, getCurrentDateTime } from '../utils/dataUtils';

interface DataFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: DataRecord) => void;
  editingRecord?: DataRecord | null;
}

export const DataForm: React.FC<DataFormProps> = ({
  isOpen,
  onClose,
  onSave,
  editingRecord
}) => {
  const [formData, setFormData] = useState<Partial<DataRecord>>({
    reason: '',
    source: '',
    scale: '',
    dateIn: '',
    bol: '',
    stumpageOwner: '',
    contractor: '',
    state: '',
    county: '',
    condition: '',
    tier: '',
    truckNumber: '',
    logCount: 0,
    avgLogLength: 0,
    avgSED: 0,
    yardDeck: '',
    comments: '',
    grossWeightIn: 0,
    tareWeightOut: 0,
    deductWeight: 0,
    adjustedNetWeight: 0,
    deductDetails: []
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (editingRecord) {
      setFormData(editingRecord);
    } else {
      setFormData({
        reason: '',
        source: '',
        scale: '',
        dateIn: new Date().toISOString().split('T')[0],
        bol: '',
        stumpageOwner: '',
        contractor: '',
        state: '',
        county: '',
        condition: '',
        tier: '',
        truckNumber: '',
        logCount: 0,
        avgLogLength: 0,
        avgSED: 0,
        yardDeck: '',
        comments: '',
        grossWeightIn: 0,
        tareWeightOut: 0,
        deductWeight: 0,
        adjustedNetWeight: 0,
        deductDetails: []
      });
    }
    setErrors({});
  }, [editingRecord, isOpen]);

  // Calculate adjusted net weight when weights change
  useEffect(() => {
    const grossWeight = formData.grossWeightIn || 0;
    const tareWeight = formData.tareWeightOut || 0;
    const deductWeight = formData.deductWeight || 0;
    const adjustedNet = grossWeight - tareWeight - deductWeight;
    
    if (adjustedNet !== formData.adjustedNetWeight) {
      setFormData(prev => ({ ...prev, adjustedNetWeight: Math.max(0, adjustedNet) }));
    }
  }, [formData.grossWeightIn, formData.tareWeightOut, formData.deductWeight]);

  // Calculate total deduct weight from deduct details
  useEffect(() => {
    const totalDeductTons = (formData.deductDetails || []).reduce((sum, detail) => sum + detail.ton, 0);
    const totalDeductWeight = totalDeductTons * 2000; // Convert tons to pounds
    
    if (totalDeductWeight !== formData.deductWeight) {
      setFormData(prev => ({ ...prev, deductWeight: totalDeductWeight }));
    }
  }, [formData.deductDetails]);

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.reason?.trim()) newErrors.reason = 'Reason is required';
    if (!formData.source?.trim()) newErrors.source = 'Source is required';
    if (!formData.dateIn) newErrors.dateIn = 'Date In is required';
    if (!formData.bol?.trim()) newErrors.bol = 'BOL is required';
    if (!formData.stumpageOwner?.trim()) newErrors.stumpageOwner = 'Stumpage Owner is required';
    if (!formData.contractor?.trim()) newErrors.contractor = 'Contractor is required';
    if (!formData.state?.trim()) newErrors.state = 'State is required';
    if (!formData.county?.trim()) newErrors.county = 'County is required';
    if (!formData.truckNumber?.trim()) newErrors.truckNumber = 'Truck Number is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    const record: DataRecord = {
      id: editingRecord?.id || generateId(),
      reason: formData.reason || '',
      source: formData.source || '',
      scale: formData.scale || '',
      dateIn: formData.dateIn || '',
      bol: formData.bol || '',
      stumpageOwner: formData.stumpageOwner || '',
      contractor: formData.contractor || '',
      state: formData.state || '',
      county: formData.county || '',
      condition: formData.condition || '',
      tier: formData.tier || '',
      truckNumber: formData.truckNumber || '',
      logCount: formData.logCount || 0,
      avgLogLength: formData.avgLogLength || 0,
      avgSED: formData.avgSED || 0,
      yardDeck: formData.yardDeck || '',
      comments: formData.comments || '',
      grossWeightIn: formData.grossWeightIn || 0,
      tareWeightOut: formData.tareWeightOut || 0,
      deductWeight: formData.deductWeight || 0,
      adjustedNetWeight: formData.adjustedNetWeight || 0,
      deductDetails: formData.deductDetails || [],
      dateCreated: editingRecord?.dateCreated || getCurrentDateTime(),
      lastModified: getCurrentDateTime()
    };

    onSave(record);
    onClose();
  };

  const handleChange = (field: keyof DataRecord, value: string | number | DeductDetail[]) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const addDeductDetail = () => {
    const newDetail: DeductDetail = {
      id: generateId(),
      code: '',
      ton: 0
    };
    setFormData(prev => ({
      ...prev,
      deductDetails: [...(prev.deductDetails || []), newDetail]
    }));
  };

  const updateDeductDetail = (id: string, field: keyof DeductDetail, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      deductDetails: (prev.deductDetails || []).map(detail =>
        detail.id === id ? { ...detail, [field]: value } : detail
      )
    }));
  };

  const removeDeductDetail = (id: string) => {
    setFormData(prev => ({
      ...prev,
      deductDetails: (prev.deductDetails || []).filter(detail => detail.id !== id)
    }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-xl max-w-6xl w-full max-h-[95vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200 sticky top-0 bg-white z-10">
          <div className="flex items-center space-x-3">
            <div className="flex items-center justify-center w-10 h-10 bg-gradient-to-r from-green-600 to-blue-600 rounded-lg">
              <Truck className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900">
                {editingRecord ? 'Edit Load Record' : 'Add New Load Record'}
              </h2>
              <p className="text-sm text-gray-500">
                {editingRecord ? 'Update load information' : 'Enter details for new load'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-8">
          {/* Basic Information */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Basic Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Reason *</label>
                <input
                  type="text"
                  value={formData.reason || ''}
                  onChange={(e) => handleChange('reason', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                    errors.reason ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="e.g., Regular Delivery, Emergency Harvest"
                />
                {errors.reason && <p className="mt-1 text-sm text-red-600">{errors.reason}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Source *</label>
                <input
                  type="text"
                  value={formData.source || ''}
                  onChange={(e) => handleChange('source', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                    errors.source ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="e.g., Forest Block A-12"
                />
                {errors.source && <p className="mt-1 text-sm text-red-600">{errors.source}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Scale</label>
                <input
                  type="text"
                  value={formData.scale || ''}
                  onChange={(e) => handleChange('scale', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors"
                  placeholder="e.g., Certified Scale #1"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Date In *</label>
                <input
                  type="date"
                  value={formData.dateIn || ''}
                  onChange={(e) => handleChange('dateIn', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                    errors.dateIn ? 'border-red-300' : 'border-gray-300'
                  }`}
                />
                {errors.dateIn && <p className="mt-1 text-sm text-red-600">{errors.dateIn}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">BOL *</label>
                <input
                  type="text"
                  value={formData.bol || ''}
                  onChange={(e) => handleChange('bol', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                    errors.bol ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Bill of Lading number"
                />
                {errors.bol && <p className="mt-1 text-sm text-red-600">{errors.bol}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Truck Number *</label>
                <input
                  type="text"
                  value={formData.truckNumber || ''}
                  onChange={(e) => handleChange('truckNumber', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                    errors.truckNumber ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="e.g., TRK-001"
                />
                {errors.truckNumber && <p className="mt-1 text-sm text-red-600">{errors.truckNumber}</p>}
              </div>
            </div>
          </div>

          {/* Parties & Location */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Parties & Location</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Stumpage Owner *</label>
                <input
                  type="text"
                  value={formData.stumpageOwner || ''}
                  onChange={(e) => handleChange('stumpageOwner', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                    errors.stumpageOwner ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Stumpage owner name"
                />
                {errors.stumpageOwner && <p className="mt-1 text-sm text-red-600">{errors.stumpageOwner}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Contractor *</label>
                <input
                  type="text"
                  value={formData.contractor || ''}
                  onChange={(e) => handleChange('contractor', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                    errors.contractor ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="Contractor name"
                />
                {errors.contractor && <p className="mt-1 text-sm text-red-600">{errors.contractor}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">State *</label>
                <select
                  value={formData.state || ''}
                  onChange={(e) => handleChange('state', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                    errors.state ? 'border-red-300' : 'border-gray-300'
                  }`}
                >
                  <option value="">Select state</option>
                  <option value="Alabama">Alabama</option>
                  <option value="Florida">Florida</option>
                  <option value="Georgia">Georgia</option>
                  <option value="North Carolina">North Carolina</option>
                  <option value="South Carolina">South Carolina</option>
                  <option value="Tennessee">Tennessee</option>
                  <option value="Virginia">Virginia</option>
                </select>
                {errors.state && <p className="mt-1 text-sm text-red-600">{errors.state}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">County *</label>
                <input
                  type="text"
                  value={formData.county || ''}
                  onChange={(e) => handleChange('county', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors ${
                    errors.county ? 'border-red-300' : 'border-gray-300'
                  }`}
                  placeholder="County name"
                />
                {errors.county && <p className="mt-1 text-sm text-red-600">{errors.county}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Condition</label>
                <select
                  value={formData.condition || ''}
                  onChange={(e) => handleChange('condition', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors"
                >
                  <option value="">Select condition</option>
                  <option value="Green">Green</option>
                  <option value="Dry">Dry</option>
                  <option value="Storm Damaged">Storm Damaged</option>
                  <option value="Mixed">Mixed</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tier</label>
                <select
                  value={formData.tier || ''}
                  onChange={(e) => handleChange('tier', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors"
                >
                  <option value="">Select tier</option>
                  <option value="Premium">Premium</option>
                  <option value="Grade A">Grade A</option>
                  <option value="Grade B">Grade B</option>
                  <option value="Grade C">Grade C</option>
                  <option value="Pulp">Pulp</option>
                </select>
              </div>
            </div>
          </div>

          {/* Log Details */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Log Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Log Count</label>
                <input
                  type="number"
                  min="0"
                  value={formData.logCount || ''}
                  onChange={(e) => handleChange('logCount', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors"
                  placeholder="Number of logs"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Avg Log Length (ft)</label>
                <input
                  type="number"
                  min="0"
                  step="0.1"
                  value={formData.avgLogLength || ''}
                  onChange={(e) => handleChange('avgLogLength', parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors"
                  placeholder="Average length"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Avg SED (in)</label>
                <input
                  type="number"
                  min="0"
                  step="0.1"
                  value={formData.avgSED || ''}
                  onChange={(e) => handleChange('avgSED', parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors"
                  placeholder="Small End Diameter"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Yard/Deck</label>
                <input
                  type="text"
                  value={formData.yardDeck || ''}
                  onChange={(e) => handleChange('yardDeck', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors"
                  placeholder="e.g., Yard 1 - Section A"
                />
              </div>
            </div>
          </div>

          {/* Weight Information */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Weight Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Gross Weight IN (lbs)</label>
                <input
                  type="number"
                  min="0"
                  value={formData.grossWeightIn || ''}
                  onChange={(e) => handleChange('grossWeightIn', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors"
                  placeholder="Gross weight"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tare Weight OUT (lbs)</label>
                <input
                  type="number"
                  min="0"
                  value={formData.tareWeightOut || ''}
                  onChange={(e) => handleChange('tareWeightOut', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors"
                  placeholder="Tare weight"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Deduct Weight (lbs)</label>
                <input
                  type="number"
                  min="0"
                  value={formData.deductWeight || ''}
                  readOnly
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-600"
                  placeholder="Auto-calculated"
                />
                <p className="text-xs text-gray-500 mt-1">Calculated from deduct details</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Adjusted Net Weight (lbs)</label>
                <input
                  type="number"
                  min="0"
                  value={formData.adjustedNetWeight || ''}
                  readOnly
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-600 font-semibold"
                  placeholder="Auto-calculated"
                />
                <p className="text-xs text-gray-500 mt-1">Gross - Tare - Deduct</p>
              </div>
            </div>
          </div>

          {/* Deduct Details */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Deduct Details</h3>
              <button
                type="button"
                onClick={addDeductDetail}
                className="flex items-center space-x-2 px-3 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Add Deduct</span>
              </button>
            </div>
            
            {(formData.deductDetails || []).length === 0 ? (
              <div className="text-center py-8 bg-gray-50 rounded-lg">
                <p className="text-gray-500">No deduct details added</p>
                <p className="text-sm text-gray-400">Click "Add Deduct" to add deduction codes and amounts</p>
              </div>
            ) : (
              <div className="space-y-3">
                {(formData.deductDetails || []).map((detail, index) => (
                  <div key={detail.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <input
                        type="text"
                        value={detail.code}
                        onChange={(e) => updateDeductDetail(detail.id, 'code', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors"
                        placeholder="Deduct code (e.g., DIRT, ROT, SCALE)"
                      />
                    </div>
                    <div className="flex-1">
                      <input
                        type="number"
                        min="0"
                        step="0.1"
                        value={detail.ton}
                        onChange={(e) => updateDeductDetail(detail.id, 'ton', parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors"
                        placeholder="Tons"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => removeDeductDetail(detail.id)}
                      className="p-2 text-red-600 hover:text-red-800 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Comments */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Comments</label>
            <textarea
              value={formData.comments || ''}
              onChange={(e) => handleChange('comments', e.target.value)}
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-colors resize-none"
              placeholder="Additional notes or comments about this load..."
            />
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors duration-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center space-x-2 px-6 py-2 bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-lg hover:from-green-700 hover:to-blue-700 transition-all duration-200 shadow-md hover:shadow-lg"
            >
              <Save className="w-4 h-4" />
              <span>{editingRecord ? 'Update' : 'Save'} Load</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};