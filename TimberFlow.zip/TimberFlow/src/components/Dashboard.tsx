import React from 'react';
import { Truck, TreePine, Scale, TrendingUp } from 'lucide-react';
import { DataRecord } from '../types';

interface DashboardProps {
  data: DataRecord[];
}

export const Dashboard: React.FC<DashboardProps> = ({ data }) => {
  const totalLoads = data.length;
  const totalLogCount = data.reduce((sum, record) => sum + record.logCount, 0);
  const totalNetWeight = data.reduce((sum, record) => sum + record.adjustedNetWeight, 0);
  const avgLogLength = data.length > 0 ? 
    data.reduce((sum, record) => sum + record.avgLogLength, 0) / data.length : 0;

  const stats = [
    {
      title: 'Total Loads',
      value: totalLoads.toLocaleString(),
      icon: Truck,
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-600'
    },
    {
      title: 'Total Logs',
      value: totalLogCount.toLocaleString(),
      icon: TreePine,
      color: 'from-emerald-500 to-emerald-600',
      bgColor: 'bg-emerald-50',
      textColor: 'text-emerald-600'
    },
    {
      title: 'Net Weight (lbs)',
      value: totalNetWeight.toLocaleString(),
      icon: Scale,
      color: 'from-orange-500 to-orange-600',
      bgColor: 'bg-orange-50',
      textColor: 'text-orange-600'
    },
    {
      title: 'Avg Log Length (ft)',
      value: avgLogLength.toFixed(1),
      icon: TrendingUp,
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-50',
      textColor: 'text-purple-600'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {stats.map((stat, index) => (
        <div
          key={index}
          className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-200"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">{stat.title}</p>
              <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
            </div>
            <div className={`${stat.bgColor} p-3 rounded-lg`}>
              <stat.icon className={`w-6 h-6 ${stat.textColor}`} />
            </div>
          </div>
          <div className="mt-4">
            <div className={`h-1 bg-gradient-to-r ${stat.color} rounded-full`}></div>
          </div>
        </div>
      ))}
    </div>
  );
};