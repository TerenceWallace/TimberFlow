import React, { useState } from 'react';
import { ChevronUp, ChevronDown, Edit, Trash2, Truck, TreePine, Scale } from 'lucide-react';
import { DataRecord, SortConfig } from '../types';

interface DataTableProps {
  data: DataRecord[];
  onEdit: (record: DataRecord) => void;
  onDelete: (id: string) => void;
  sortConfig: SortConfig;
  onSort: (key: keyof DataRecord) => void;
}

export const DataTable: React.FC<DataTableProps> = ({
  data,
  onEdit,
  onDelete,
  sortConfig,
  onSort
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const recordsPerPage = 10;

  const totalPages = Math.ceil(data.length / recordsPerPage);
  const startIndex = (currentPage - 1) * recordsPerPage;
  const endIndex = startIndex + recordsPerPage;
  const currentData = data.slice(startIndex, endIndex);

  const getSortIcon = (key: keyof DataRecord) => {
    if (sortConfig.key !== key) {
      return <ChevronUp className="w-4 h-4 text-gray-400" />;
    }
    return sortConfig.direction === 'asc' ? 
      <ChevronUp className="w-4 h-4 text-blue-500" /> : 
      <ChevronDown className="w-4 h-4 text-blue-500" />;
  };

  const getConditionBadge = (condition: string) => {
    const styles: Record<string, string> = {
      'Green': 'bg-emerald-100 text-emerald-800 border-emerald-200',
      'Dry': 'bg-yellow-100 text-yellow-800 border-yellow-200',
      'Storm Damaged': 'bg-red-100 text-red-800 border-red-200',
      'Mixed': 'bg-blue-100 text-blue-800 border-blue-200'
    };
    return (
      <span className={`px-2 py-1 text-xs font-medium rounded-full border ${styles[condition] || 'bg-gray-100 text-gray-800 border-gray-200'}`}>
        {condition || 'N/A'}
      </span>
    );
  };

  const getTierBadge = (tier: string) => {
    const styles: Record<string, string> = {
      'Premium': 'bg-purple-100 text-purple-800 border-purple-200',
      'Grade A': 'bg-green-100 text-green-800 border-green-200',
      'Grade B': 'bg-blue-100 text-blue-800 border-blue-200',
      'Grade C': 'bg-orange-100 text-orange-800 border-orange-200',
      'Pulp': 'bg-gray-100 text-gray-800 border-gray-200'
    };
    return (
      <span className={`px-2 py-1 text-xs font-medium rounded-full border ${styles[tier] || 'bg-gray-100 text-gray-800 border-gray-200'}`}>
        {tier || 'N/A'}
      </span>
    );
  };

  if (data.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
        <div className="max-w-md mx-auto">
          <div className="mb-4">
            <Truck className="w-12 h-12 text-gray-400 mx-auto" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No load records found</h3>
          <p className="text-gray-500 mb-6">
            Get started by adding your first load record to the system.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              {[
                { key: 'dateIn', label: 'Date In' },
                { key: 'bol', label: 'BOL' },
                { key: 'truckNumber', label: 'Truck #' },
                { key: 'contractor', label: 'Contractor' },
                { key: 'source', label: 'Source' },
                { key: 'condition', label: 'Condition' },
                { key: 'tier', label: 'Tier' },
                { key: 'logCount', label: 'Logs' },
                { key: 'adjustedNetWeight', label: 'Net Weight' }
              ].map(({ key, label }) => (
                <th
                  key={key}
                  onClick={() => onSort(key as keyof DataRecord)}
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center space-x-1">
                    <span>{label}</span>
                    {getSortIcon(key as keyof DataRecord)}
                  </div>
                </th>
              ))}
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {currentData.map((record) => (
              <tr key={record.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {record.dateIn}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900">{record.bol}</div>
                  <div className="text-sm text-gray-500">{record.reason}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-8 w-8">
                      <div className="h-8 w-8 rounded-full bg-gradient-to-r from-green-500 to-blue-500 flex items-center justify-center">
                        <Truck className="w-4 h-4 text-white" />
                      </div>
                    </div>
                    <div className="ml-3">
                      <div className="text-sm font-medium text-gray-900">{record.truckNumber}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{record.contractor}</div>
                  <div className="text-sm text-gray-500">{record.stumpageOwner}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{record.source}</div>
                  <div className="text-sm text-gray-500">{record.state}, {record.county}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {getConditionBadge(record.condition)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {getTierBadge(record.tier)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center text-sm text-gray-900">
                    <TreePine className="w-4 h-4 mr-1 text-green-500" />
                    {record.logCount}
                  </div>
                  <div className="text-sm text-gray-500">
                    Avg: {record.avgLogLength}ft × {record.avgSED}"
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center text-sm font-medium text-gray-900">
                    <Scale className="w-4 h-4 mr-1 text-blue-500" />
                    {record.adjustedNetWeight.toLocaleString()} lbs
                  </div>
                  {record.deductDetails.length > 0 && (
                    <div className="text-sm text-gray-500">
                      -{record.deductWeight.toLocaleString()} deduct
                    </div>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <div className="flex items-center justify-end space-x-2">
                    <button
                      onClick={() => onEdit(record)}
                      className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors"
                      title="Edit load record"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onDelete(record.id)}
                      className="p-2 text-red-600 hover:text-red-800 hover:bg-red-50 rounded-lg transition-colors"
                      title="Delete load record"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="bg-white px-4 py-3 border-t border-gray-200 sm:px-6">
          <div className="flex items-center justify-between">
            <div className="flex-1 flex justify-between sm:hidden">
              <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Previous
              </button>
              <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
              </button>
            </div>
            <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
              <div>
                <p className="text-sm text-gray-700">
                  Showing <span className="font-medium">{startIndex + 1}</span> to{' '}
                  <span className="font-medium">{Math.min(endIndex, data.length)}</span> of{' '}
                  <span className="font-medium">{data.length}</span> results
                </p>
              </div>
              <div>
                <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                  <button
                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                    className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ChevronUp className="h-5 w-5 transform -rotate-90" />
                  </button>
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                    <button
                      key={page}
                      onClick={() => setCurrentPage(page)}
                      className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                        page === currentPage
                          ? 'z-10 bg-blue-50 border-blue-500 text-blue-600'
                          : 'bg-white border-gray-300 text-gray-500 hover:bg-gray-50'
                      }`}
                    >
                      {page}
                    </button>
                  ))}
                  <button
                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages}
                    className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ChevronUp className="h-5 w-5 transform rotate-90" />
                  </button>
                </nav>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};