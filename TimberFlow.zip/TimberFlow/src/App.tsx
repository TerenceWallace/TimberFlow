import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { DataForm } from './components/DataForm';
import { DataTable } from './components/DataTable';
import { FilterPanel } from './components/FilterPanel';
import { LoginForm } from './components/LoginForm';
import { useLocalStorage } from './hooks/useLocalStorage';
import { useAuth } from './hooks/useAuth';
import { DataRecord, FilterOptions, SortConfig } from './types';
import { filterData, sortData, exportToCSV } from './utils/dataUtils';
import { sampleData } from './data/sampleData';

function App() {
  const { isAuthenticated, user, loading, login, logout } = useAuth();
  const [data, setData] = useLocalStorage<DataRecord[]>('dataflow-records', sampleData);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<DataRecord | null>(null);
  const [filters, setFilters] = useState<FilterOptions>({
    search: '',
    source: '',
    condition: '',
    tier: '',
    state: '',
    contractor: ''
  });
  const [sortConfig, setSortConfig] = useState<SortConfig>({
    key: 'dateIn',
    direction: 'desc'
  });

  const sources = useMemo(() => {
    const sourceList = [...new Set(data.map(record => record.source).filter(Boolean))];
    return sourceList.sort();
  }, [data]);

  const contractors = useMemo(() => {
    const contractorList = [...new Set(data.map(record => record.contractor).filter(Boolean))];
    return contractorList.sort();
  }, [data]);

  const states = useMemo(() => {
    const stateList = [...new Set(data.map(record => record.state).filter(Boolean))];
    return stateList.sort();
  }, [data]);

  const filteredAndSortedData = useMemo(() => {
    const filtered = filterData(data, filters);
    return sortData(filtered, sortConfig);
  }, [data, filters, sortConfig]);

  const handleAddNew = () => {
    setEditingRecord(null);
    setIsFormOpen(true);
  };

  const handleEdit = (record: DataRecord) => {
    setEditingRecord(record);
    setIsFormOpen(true);
  };

  const handleSave = (record: DataRecord) => {
    if (editingRecord) {
      setData(prev => prev.map(r => r.id === record.id ? record : r));
    } else {
      setData(prev => [record, ...prev]);
    }
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this load record?')) {
      setData(prev => prev.filter(r => r.id !== id));
    }
  };

  const handleSort = (key: keyof DataRecord) => {
    setSortConfig(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleExport = () => {
    exportToCSV(filteredAndSortedData, 'logging-data-export.csv');
  };

  const handleSearchChange = (search: string) => {
    setFilters(prev => ({ ...prev, search }));
  };

  // Show login form if not authenticated
  if (!isAuthenticated) {
    return <LoginForm onLogin={login} loading={loading} />;
  }

  // Show main application if authenticated
  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        onAddNew={handleAddNew}
        onExport={handleExport}
        searchValue={filters.search}
        onSearchChange={handleSearchChange}
        user={user!}
        onLogout={logout}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Dashboard data={data} />
        
        <FilterPanel
          filters={filters}
          onFilterChange={setFilters}
          sources={sources}
          contractors={contractors}
          states={states}
        />
        
        <DataTable
          data={filteredAndSortedData}
          onEdit={handleEdit}
          onDelete={handleDelete}
          sortConfig={sortConfig}
          onSort={handleSort}
        />
      </main>

      <DataForm
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        onSave={handleSave}
        editingRecord={editingRecord}
      />
    </div>
  );
}

export default App;